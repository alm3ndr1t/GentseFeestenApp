﻿using System;
using Domain;
using Cui;
using Persistentielaag;
using Domain.Interface;

namespace StartUp;
public class StartUp
{
    static void Main(string[] args)
    {
        IEvenRepository eventRepo = new EvenementRepository();
        IEvenementPlanner plannerRepo = new PlannerRepo();
        DomainController dc = new DomainController(eventRepo, plannerRepo);
        GentseFeestenApp app = new GentseFeestenApp(dc);
        app.Run();
    }
}