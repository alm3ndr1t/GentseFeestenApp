﻿using Domain.Models;

namespace Domain.Interface
{
    public interface IEvenRepository
    {
        List<Evenement> GeefEvenement();

    }
}
