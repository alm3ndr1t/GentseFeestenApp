﻿namespace Domain.Interface
{
    public interface IEvenementPlanner
    {
        void AddToPlanner(IEvenement evenement);
        void RemoveFromPlanner(IEvenement evenement);
        List<IEvenement> GetEvenementsFromPlanner();

    }
}
