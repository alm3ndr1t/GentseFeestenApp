﻿namespace Domain.Interface
{
    public interface IEvenement
    {
        int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string Titel { get; set; }
        public string Beschrijving { get; set; }
        public DateTime Datum { get; set; }
        public TimeSpan Tijdsduur { get; set; }
        public decimal KostPrijs { get; set; }
    }
}
