﻿using System.Runtime.Serialization;

namespace Domain.Exceptions
{
    public class EvenementException : Exception
    {
        public EvenementException()
        {
        }
        public EvenementException(string massage) : base(massage)
        {
        }
        public EvenementException(string massage, Exception innerException) : base(massage, innerException)
        {
        }
        public EvenementException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
