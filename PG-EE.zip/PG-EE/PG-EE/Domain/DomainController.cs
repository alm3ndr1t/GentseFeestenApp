﻿using Domain.Interface;

namespace Domain
{
    public class DomainController
    {
        private IEvenRepository _repo;

        public DomainController (IEvenRepository repo, IEvenementPlanner plannerRepo)
        {
            _repo = repo;
        }
    }
}