﻿using Domain.Exceptions;
using Domain.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class EvenementenPlanner
    {
        private IEvenementPlanner _plannerRepo;
        public EvenementenPlanner (IEvenementPlanner plannerRepo)
        {
            _plannerRepo = plannerRepo;
        }

        public List<IEvenement> GetEvenementsFromPlanner()
        {
            return _plannerRepo.GetEvenementsFromPlanner();
        }

        public void AddToPlanner(IEvenement evenement)
        {
            if (IsEvenementAlreadyAdded(evenement))
            {
                throw new EvenementException("Deze evenement is al toegevoegd!");
            }
            if (IsEvenementAlreadyAdded(evenement))
            {
                throw new EvenementException("Deze evenement overlapt met een andere evenement!");
            }
            _plannerRepo.AddToPlanner(evenement);
        }

        // Controleer of het evenement al is toegevoegd aan het dagplan:
        public bool IsEvenementAlreadyAdded(IEvenement evenement)
        {
            bool evenementIsInPlanner = false;
            foreach (IEvenement e in GetEvenementsFromPlanner())
            {
                if (e.Id == evenement.Id)
                {
                    evenementIsInPlanner = true;
                    break;
                }
            }
            return evenementIsInPlanner;
        }

        // Controleer of het evenement overlapt met andere evenementen:
        public bool IsEvenementOverlapping(Dagplan dagplan, Evenement evenement)
        {
            foreach (var existingEvenement in dagplan.Evenementen)
            {
                if (existingEvenement.StartDate < evenement.EndDate && existingEvenement.EndDate > evenement.StartDate)
                {
                    return true; // Er is overlapping
                }
            }
            return false; // Geen overlapping
        }

        // Controleer of het evenement op dezelfde datum plaatsvindt:
        public bool IsEvenementOnSameDate(Dagplan dagplan, Evenement evenement)
        {
            if (dagplan.Datum == evenement.Datum)
            {
                return true;
            }else
            {
                return false;
            }
        }

        // Controleer of de gebruiker al een dagplan heeft aangemaakt voor dezelfde dag:
        public bool HasBezoekerAlreadyCreatedDagplan(Bezoeker bezoeker, DateTime datum)
        {
            return bezoeker.Dagplannen.Any(d => d.Datum == datum);
        }

        // Controleer of er minstens 30 minuten tussen evenementen zitten:
        public bool IsMinimaal30MinutenTussenEvenementen(Dagplan dagplan)
        {
            var sortedEvenementen = dagplan.Evenementen.OrderBy(e => e.StartDate).ToList();
            for (int i = 1; i < sortedEvenementen.Count; i++)
            {
                var previousEvenement = sortedEvenementen[i - 1];
                var currentEvenement = sortedEvenementen[i];

                if (currentEvenement.StartDate - previousEvenement.EndDate < TimeSpan.FromMinutes(30))
                {
                    return false; // Minder dan 30 minuten tussen evenementen
                }
            }
            return true; // Minimaal 30 minuten tussen evenementen
        }

        // Controleer of de totale kostprijs van de evenementen het beschikbare dagbudget niet overschrijdt:
        public bool IsKostprijsWithinBudget(Dagplan dagplan, decimal beschikbaarBudget)
        {
            decimal totaleKostprijs = dagplan.Evenementen.Sum(e => e.KostPrijs);
            return totaleKostprijs <= beschikbaarBudget;
        }

    }
}
