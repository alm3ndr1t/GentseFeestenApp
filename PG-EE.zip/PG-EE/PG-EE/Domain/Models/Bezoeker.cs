﻿namespace Domain.Models
{
    public class Bezoeker
    {
        public Bezoeker(string naam, string voornaam,Dagplan dagplannen, decimal resterendeDagBudget )
        {
            Naam = naam;
            Voornaam = voornaam;
           // Dagplan Dagplannen = dagplannen;
            ResterendDagbudget = resterendeDagBudget;
        }

        public string Naam { get; set; }
        public string Voornaam { get; set; }
        public List<Dagplan> Dagplannen { get; set; }
        public decimal ResterendDagbudget { get; set; }
    }
}
