﻿using Domain.Exceptions;
using System.Text;

namespace Domain.Models
{
    public class Evenement
    {
        private int _id;
        public int Id
        {
            get { return _id; }
            set
            {
                if (value <= 0)
                {
                    throw new EvenementException("id can't be null");
                }
                _id = value;
            }
        }

        private string _identifier;
        public string Identifier
        {
            get { return _identifier; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new EvenementException("Unique Id can not be null or empty");
                }
                _identifier = value;
            }
        }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string Titel { get; set; }
        public string Beschrijving { get; set; }
        public DateTime Datum { get; set; }
        public TimeSpan Tijdsduur { get; set; }
        public decimal KostPrijs { get; set; }

        public Evenement(int id, string identifier, DateTime startDate, DateTime endDate, string titel, string beschrijving, DateTime datum, TimeSpan tijdsduur, decimal kostPrijs)
        {
            Id = id;
            Identifier = identifier;
            StartDate = startDate;
            EndDate = endDate;
            Titel = titel;
            Beschrijving = beschrijving;
            Datum = datum;
            Tijdsduur = tijdsduur;
            KostPrijs = kostPrijs;
        }
    }
}
