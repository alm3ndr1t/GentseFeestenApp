﻿namespace Domain.Models
{
    public class Dagplan
    {
        public Dagplan(DateTime datum, Bezoeker bezoeker, Evenement evenement, decimal totaleKostprijs)
        {
            Datum = datum;
            Bezoeker = bezoeker;
            // Evenementen = evenement;
            // TotaleKostprijs = totaleKostprijs;
        }


        public DateTime Datum { get; set; }
        public Bezoeker Bezoeker { get; set; }
        public List<Evenement> Evenementen { get; set; }
        public decimal TotaleKostprijs => Evenementen.Sum(e => e.KostPrijs);
    }
}
