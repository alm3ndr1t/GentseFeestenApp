﻿using Domain;

namespace Cui
{
    public class GentseFeestenApp
    {
        private DomainController _dc;
        public GentseFeestenApp(DomainController dc)
        {
            _dc = dc;
        }

        public void Run()
        {
        }
    }
}