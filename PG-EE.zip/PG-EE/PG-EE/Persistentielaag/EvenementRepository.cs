﻿using Domain.Interface;
using Domain.Models;

namespace Persistentielaag
{
    public class EvenementRepository : IEvenRepository
    {
        public List<Evenement> GeefEvenement()
        {
            throw new NotImplementedException();
        }
    }
}