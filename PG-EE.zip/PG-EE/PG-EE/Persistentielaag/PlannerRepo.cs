﻿using Domain.Interface;
using Domain.Models;
using Microsoft.Data.SqlClient;

namespace Persistentielaag
{
    public class PlannerRepo : IEvenementPlanner
    {
        // connectie database
        private const string connectionString = 
            @"Data Source=.\SQLEXPRESS; Initial Catalog=GentseFeestenDb;Integrated Security=True;Trusted_Connection=True;";

        public void AddToPlanner(IEvenement evenement)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string insertSql = "INSERT INTO dagplan (EventId) VALUES (@eventid)";
                    SqlCommand insertCommand = new SqlCommand(insertSql, connection);
                    insertCommand.Parameters.AddWithValue("@eventid", evenement.Id);

                    insertCommand.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void RemoveFromPlanner(IEvenement evenement)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string deleteSql = "DELETE FROM dagplan WHERE EventId = @eventid";
                    SqlCommand deleteCommand = new SqlCommand(deleteSql, connection);

                    deleteCommand.Parameters.AddWithValue("@eventid", evenement.Id);

                    deleteCommand.ExecuteNonQuery();
                }
            }
            catch { throw; }
        }

        public List<IEvenement> GetEvenementsFromPlanner()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string selectSql = "SELECT * FROM evenementen JOIN dagplan on dagplan.eventid = evenement.eventid  ";
                    using (SqlCommand selectCommand = new SqlCommand(selectSql, connection))
                    {
                        SqlDataReader reader = selectCommand.ExecuteReader();
                        List<IEvenement> events = new List<IEvenement>();
                        while (reader.Read())
                        {
                            int eventId = (int)reader["eventid"];
                            IEvenement evenement = GetEventById(eventId);
                            events.Add(evenement);
                        }

                        return events;
                    }
                }
            }
            catch { throw; }
        }

        private IEvenement GetEventById(int eventId)
        {
            /* try
              {
                  using (SqlConnection connection = new SqlConnection(connectionString))
                  {
                      connection.Open();

                      string sql = "SELECT * FROM evenement WHERE Eventid = @id";
                      SqlCommand command = new SqlCommand(sql, connection);
                      command.Parameters.AddWithValue("@id", eventId);

                      using (SqlDataReader reader = command.ExecuteReader())
                      {
                          if (reader.Read())
                          {
                              int Id = reader.GetInt32(0);
                              string uniqueId = reader.GetString(1);
                              DateTime startDate = reader.GetDateTime(2);
                              DateTime endDate = reader.GetDateTime(3);
                              int parentId = reader.IsDBNull(4) ? 0 : reader.GetInt32(4);
                              string parentUniqueId = reader.GetString(5);
                              string name = reader.GetString(6);
                              string description = reader.GetString(7);
                              decimal price = reader.GetDecimal(8);

                              return new Evenement(eventId, uniqueId, startDate, endDate, parentId, parentUniqueId, name, description, price);
                          } else
                          {
                              return null;
                          }
                      }
                  }
              }
              catch { throw; } */
            throw new NotImplementedException();
        }
    }
}